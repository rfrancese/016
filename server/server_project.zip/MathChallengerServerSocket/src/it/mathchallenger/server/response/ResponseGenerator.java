package it.mathchallenger.server.response;

import org.w3c.dom.Document;

public class ResponseGenerator {
	public static Document generaEmptyDocument(){
		return null;
	}
}
